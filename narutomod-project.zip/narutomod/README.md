# Naruto Mod (Fabric 1.20.1)

Items: Kunai, Shuriken (throwable), Rasengan Scroll, Fire Style Scroll, Body Flicker Scroll, Ichiraku Ramen.
Find them in the creative tab "Naruto Mod". Requires Fabric Loader + Fabric API.

Build: upload this folder to a GitHub repo -> Actions tab -> "build" -> download the artifact jar.
Or on a PC: `gradle build` (Gradle 8.5+, Java 17) -> build/libs/narutomod-1.0.0.jar
