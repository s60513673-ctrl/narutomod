package com.narutomod.entity;

import com.narutomod.ModEntities;
import com.narutomod.ModItems;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;

public class ShurikenEntity extends ThrownItemEntity {
	public ShurikenEntity(EntityType<? extends ShurikenEntity> type, World world) {
		super(type, world);
	}

	public ShurikenEntity(World world, LivingEntity owner) {
		super(ModEntities.SHURIKEN, owner, world);
	}

	@Override
	protected Item getDefaultItem() {
		return ModItems.SHURIKEN;
	}

	@Override
	protected void onEntityHit(EntityHitResult hit) {
		super.onEntityHit(hit);
		Entity target = hit.getEntity();
		target.damage(this.getDamageSources().thrown(this, this.getOwner()), 5.0f);
	}

	@Override
	protected void onCollision(HitResult hit) {
		super.onCollision(hit);
		if (!this.getWorld().isClient) {
			this.getWorld().sendEntityStatus(this, (byte) 3);
			this.discard();
		}
	}
}
