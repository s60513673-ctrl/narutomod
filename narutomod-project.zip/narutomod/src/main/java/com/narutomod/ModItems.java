package com.narutomod;

import com.narutomod.item.FireballScrollItem;
import com.narutomod.item.RasenganScrollItem;
import com.narutomod.item.ShurikenItem;
import com.narutomod.item.SpeedScrollItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public class ModItems {
	public static final Item KUNAI = register("kunai",
		new SwordItem(ToolMaterials.IRON, 2, -1.8f, new FabricItemSettings()));

	public static final Item SHURIKEN = register("shuriken",
		new ShurikenItem(new FabricItemSettings().maxCount(16)));

	public static final Item RASENGAN_SCROLL = register("rasengan_scroll",
		new RasenganScrollItem(new FabricItemSettings().maxDamage(32)));

	public static final Item FIRE_SCROLL = register("fire_scroll",
		new FireballScrollItem(new FabricItemSettings().maxDamage(32)));

	public static final Item SPEED_SCROLL = register("speed_scroll",
		new SpeedScrollItem(new FabricItemSettings().maxDamage(32)));

	public static final Item ICHIRAKU_RAMEN = register("ichiraku_ramen",
		new Item(new FabricItemSettings().maxCount(16).food(
			new FoodComponent.Builder().hunger(10).saturationModifier(0.8f).build())));

	public static final ItemGroup NARUTO_GROUP = Registry.register(
		Registries.ITEM_GROUP,
		NarutoMod.id("naruto"),
		FabricItemGroup.builder()
			.displayName(Text.translatable("itemGroup.narutomod.naruto"))
			.icon(() -> new ItemStack(SHURIKEN))
			.entries((context, entries) -> {
				entries.add(KUNAI);
				entries.add(SHURIKEN);
				entries.add(RASENGAN_SCROLL);
				entries.add(FIRE_SCROLL);
				entries.add(SPEED_SCROLL);
				entries.add(ICHIRAKU_RAMEN);
			})
			.build()
	);

	private static Item register(String name, Item item) {
		return Registry.register(Registries.ITEM, NarutoMod.id(name), item);
	}

	public static void register() {
		// Loading this class registers the items above.
	}
}
