package com.narutomod.item;

import com.narutomod.entity.ShurikenEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ShurikenItem extends Item {
	public ShurikenItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);
		world.playSound(null, user.getX(), user.getY(), user.getZ(),
			SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.PLAYERS,
			0.6f, 0.4f / (world.getRandom().nextFloat() * 0.4f + 0.8f));

		if (!world.isClient) {
			ShurikenEntity shuriken = new ShurikenEntity(world, user);
			shuriken.setItem(stack);
			shuriken.setVelocity(user, user.getPitch(), user.getYaw(), 0.0f, 2.5f, 1.0f);
			world.spawnEntity(shuriken);
		}

		user.incrementStat(Stats.USED.getOrCreateStat(this));
		if (!user.getAbilities().creativeMode) {
			stack.decrement(1);
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
