package com.narutomod.item;

import java.util.List;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Rasengan: a powerful close-range strike that launches enemies away. */
public class RasenganScrollItem extends Item {
	public RasenganScrollItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (!world.isClient) {
			Vec3d look = user.getRotationVec(1.0f);
			Box area = user.getBoundingBox().stretch(look.multiply(3.5)).expand(1.0);
			List<LivingEntity> targets = world.getEntitiesByClass(
				LivingEntity.class, area, e -> e != user && e.isAlive());

			for (LivingEntity target : targets) {
				target.damage(world.getDamageSources().playerAttack(user), 12.0f);
				target.addVelocity(look.x * 1.8, 0.6, look.z * 1.8);
				target.velocityModified = true;
			}

			Vec3d tip = user.getEyePos().add(look.multiply(2.0));
			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME,
					tip.x, tip.y, tip.z, 40, 0.4, 0.4, 0.4, 0.05);
				serverWorld.spawnParticles(ParticleTypes.EXPLOSION,
					tip.x, tip.y, tip.z, 1, 0.0, 0.0, 0.0, 0.0);
			}
			world.playSound(null, user.getX(), user.getY(), user.getZ(),
				SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.PLAYERS, 0.6f, 1.6f);

			user.addExhaustion(3.0f); // chakra cost = hunger
			user.getItemCooldownManager().set(this, 60);
			stack.damage(1, user, p -> p.sendToolBreakStatus(hand));
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
