package com.narutomod.item;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Body Flicker: a burst of ninja speed and jumping power. */
public class SpeedScrollItem extends Item {
	public SpeedScrollItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (!world.isClient) {
			user.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 20 * 15, 3));
			user.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 20 * 15, 1));

			if (world instanceof ServerWorld serverWorld) {
				serverWorld.spawnParticles(ParticleTypes.CLOUD,
					user.getX(), user.getY() + 0.5, user.getZ(), 30, 0.4, 0.6, 0.4, 0.05);
			}
			world.playSound(null, user.getX(), user.getY(), user.getZ(),
				SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 0.7f, 1.4f);

			user.addExhaustion(2.0f);
			user.getItemCooldownManager().set(this, 20 * 20);
			stack.damage(1, user, p -> p.sendToolBreakStatus(hand));
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
