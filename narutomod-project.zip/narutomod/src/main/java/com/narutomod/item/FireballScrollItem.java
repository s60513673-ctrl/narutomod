package com.narutomod.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.SmallFireballEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Fire Style: Fireball Jutsu - shoots a spread of three fireballs. */
public class FireballScrollItem extends Item {
	public FireballScrollItem(Settings settings) {
		super(settings);
	}

	@Override
	public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
		ItemStack stack = user.getStackInHand(hand);

		if (!world.isClient) {
			Vec3d look = user.getRotationVec(1.0f);
			for (int i = -1; i <= 1; i++) {
				Vec3d dir = look.rotateY(i * 0.25f);
				SmallFireballEntity fireball = new SmallFireballEntity(world, user, dir.x, dir.y, dir.z);
				fireball.setPosition(
					user.getX() + dir.x * 1.2,
					user.getEyeY() - 0.2 + dir.y * 1.2,
					user.getZ() + dir.z * 1.2);
				fireball.setVelocity(dir.multiply(1.2));
				world.spawnEntity(fireball);
			}
			world.playSound(null, user.getX(), user.getY(), user.getZ(),
				SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1.0f, 1.0f);

			user.addExhaustion(2.0f);
			user.getItemCooldownManager().set(this, 40);
			stack.damage(1, user, p -> p.sendToolBreakStatus(hand));
		}
		return TypedActionResult.success(stack, world.isClient());
	}
}
